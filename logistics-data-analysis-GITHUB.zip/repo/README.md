# Advanced Data Analysis and Visualization in Logistics

Week 3 Task — end-to-end analytical workflow (data simulation → EDA → visualization →
reporting) applied to a simulated logistics dataset of 1,500 shipments.

## 📁 Repository Structure

```
.
├── data/
│   └── logistics_data.csv          # Simulated shipment-level dataset (1,500 rows)
├── scripts/
│   ├── 01_simulate_data.py         # Step 1: generates data/logistics_data.csv
│   ├── 02_eda.py                   # Step 2: descriptive stats, correlations, on-time analysis
│   ├── 03_visualize.py             # Step 3: generates all 7 charts into charts/
│   └── build_report.js             # Step 5: assembles the final Word report (docx)
├── charts/                         # PNG output from 03_visualize.py (7 charts)
├── docs/                           # Text/CSV EDA output (summary stats, correlation matrix)
├── report/
│   └── Logistics_Data_Analysis_Report.docx   # ⭐ Final submission deliverable
├── requirements.txt                # Python dependencies
├── package.json                    # Node dependency (docx) for report generation
└── README.md
```

## 🎯 Objective

Analyze a hypothetical logistics dataset covering delivery times, shipment volumes, and
transportation costs; identify operational bottlenecks and cost drivers through EDA and
visualization; and document the process and findings in a professional report.

## 🧪 Dataset

1,500 simulated shipments across 2025, with the following fields: `shipment_id`,
`ship_date`, `region` (5), `carrier` (4), `mode` (Road/Rail/Air/Sea), `distance_km`,
`shipment_volume_kg`, `transportation_cost_usd`, `fuel_surcharge_pct`,
`planned_delivery_days`, `actual_delivery_days`, `delay_days`, `delayed`.

Cost and delivery time are generated from mode-specific parameters (cost/km, speed/day)
plus a deliberate November–December congestion effect, so the dataset contains
realistic, discoverable operational patterns rather than pure noise.

## 🔑 Key Findings

- Overall on-time delivery rate: **52.9%** (Air 81.8% vs. Road 42.9%)
- **Peak-season bottleneck**: on-time rate collapses to ~22% in Nov–Dec
- Air freight costs **~6x more per km** than Sea freight
- Cost and delivery-time correlations are mode-dependent — blended averages mislead

Full analysis, charts, and recommendations are in
[`report/Logistics_Data_Analysis_Report.docx`](report/Logistics_Data_Analysis_Report.docx).

## ▶️ Reproducing the Analysis

```bash
# 1. Install Python dependencies
pip install -r requirements.txt

# 2. Run the pipeline in order
cd scripts
python 01_simulate_data.py     # -> ../data/logistics_data.csv
python 02_eda.py                # -> ../docs/*.csv, eda_summary.txt
python 03_visualize.py          # -> ../charts/*.png

# 3. (Optional) Rebuild the Word report
npm install
node build_report.js            # -> report/Logistics_Data_Analysis_Report.docx
```

## 🛠️ Tools Used

Python 3 · pandas · NumPy · matplotlib · seaborn · Node.js (`docx` package, for report
generation only)

## 📄 License

For educational/coursework use.
