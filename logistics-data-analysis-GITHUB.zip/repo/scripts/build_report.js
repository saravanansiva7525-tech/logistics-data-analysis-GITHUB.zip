const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, ImageRun,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  AlignmentType, PageBreak, LevelFormat, convertInchesToTwip,
  Header, Footer, PageNumber, VerticalAlign
} = require("docx");

const PAGE_W = 12240, PAGE_H = 15840; // US Letter
const CONTENT_W = PAGE_W - convertInchesToTwip(1) * 2; // 1in margins each side

// ---------- brand system ----------
// Font pairing: Cambria (serif, editorial) for headings + Calibri (clean sans) for body
const FONT_HEAD = "Cambria";
const FONT_BODY = "Calibri";
const FONT_MONO = "Consolas";

const COLORS = {
  teal: "0B5D57",       // primary
  tealDark: "07403C",
  gold: "D4A017",       // accent
  coral: "E2725B",      // secondary accent
  navy: "1B3A4B",
  ink: "222B2B",
  gray: "5C6B6B",
  mint: "EAF5F1",       // light shading
  cream: "FBF7EE",
};

function heading1(num, text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 480, after: 200 },
    border: { bottom: { color: COLORS.gold, space: 6, style: BorderStyle.SINGLE, size: 12 } },
    children: [
      new TextRun({ text: `${num}  `, bold: true, color: COLORS.gold, font: FONT_HEAD, size: 32 }),
      new TextRun({ text, bold: true, color: COLORS.teal, font: FONT_HEAD, size: 32 }),
    ],
  });
}
function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 320, after: 150 },
    indent: { left: 130 },
    border: { left: { color: COLORS.coral, space: 8, style: BorderStyle.SINGLE, size: 18 } },
    children: [new TextRun({ text, bold: true, color: COLORS.navy, font: FONT_HEAD, size: 25 })],
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 160, line: 276 },
    children: [new TextRun({ text, size: 22, font: FONT_BODY, color: COLORS.ink, ...opts })],
  });
}
function bullet(text) {
  return new Paragraph({
    spacing: { after: 100 },
    numbering: { reference: "bullet-list", level: 0 },
    children: [new TextRun({ text, size: 22, font: FONT_BODY, color: COLORS.ink })],
  });
}
function caption(text) {
  return new Paragraph({
    spacing: { before: 80, after: 260 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text, italics: true, size: 19, font: FONT_BODY, color: COLORS.coral, bold: true })],
  });
}
// Colored callout box (left accent border + tint fill) — used for "Why this chart" / "Insight"
function callout(label, text, accentColor, fillColor) {
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [CONTENT_W],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: CONTENT_W, type: WidthType.DXA },
            shading: { type: ShadingType.CLEAR, fill: fillColor },
            margins: { top: 130, bottom: 130, left: 220, right: 220 },
            borders: {
              left: { style: BorderStyle.SINGLE, size: 24, color: accentColor },
              top: { style: BorderStyle.SINGLE, size: 2, color: fillColor },
              bottom: { style: BorderStyle.SINGLE, size: 2, color: fillColor },
              right: { style: BorderStyle.SINGLE, size: 2, color: fillColor },
            },
            children: [
              new Paragraph({
                spacing: { after: 40 },
                children: [new TextRun({ text: label, bold: true, font: FONT_HEAD, color: accentColor, size: 20 })],
              }),
              new Paragraph({
                children: [new TextRun({ text, size: 21, font: FONT_BODY, color: COLORS.ink })],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function codeBlock(lines) {
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [CONTENT_W],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: CONTENT_W, type: WidthType.DXA },
            shading: { type: ShadingType.CLEAR, fill: "1E2B2A" },
            margins: { top: 140, bottom: 140, left: 200, right: 200 },
            borders: {
              left: { style: BorderStyle.SINGLE, size: 24, color: COLORS.gold },
            },
            children: lines.map((l) => new Paragraph({
              spacing: { after: 20 },
              children: [new TextRun({ text: l, font: FONT_MONO, size: 18, color: "E8F5F0" })],
            })),
          }),
        ],
      }),
    ],
  });
}
function imageParagraph(path, widthIn, heightIn) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 200 },
    children: [
      new ImageRun({
        type: "png",
        data: fs.readFileSync(path),
        transformation: { width: convertInchesToTwip(widthIn) / 15, height: convertInchesToTwip(heightIn) / 15 },
      }),
    ],
  });
}
// docx expects pixel-ish values for transformation width/height (EMU handled internally);
// simpler: use fixed pixel numbers directly.
function img(path, width = 560, height = 350) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 200 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(path), transformation: { width, height } })],
  });
}

function dataTable(headerRow, dataRows, colWidths) {
  const total = colWidths.reduce((a, b) => a + b, 0);
  const rows = [];
  rows.push(new TableRow({
    tableHeader: true,
    children: headerRow.map((h, i) => new TableCell({
      width: { size: colWidths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: COLORS.teal },
      margins: { top: 90, bottom: 90, left: 130, right: 130 },
      children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", font: FONT_HEAD, size: 20 })] })],
    })),
  }));
  dataRows.forEach((r, ri) => {
    rows.push(new TableRow({
      children: r.map((c, i) => new TableCell({
        width: { size: colWidths[i], type: WidthType.DXA },
        shading: { type: ShadingType.CLEAR, fill: ri % 2 === 0 ? "FFFFFF" : COLORS.mint },
        margins: { top: 75, bottom: 75, left: 130, right: 130 },
        children: [new Paragraph({ children: [new TextRun({ text: String(c), size: 19, font: FONT_BODY, color: COLORS.ink })] })],
      })),
    }));
  });
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: colWidths, rows });
}

function sectionBreakSpace() {
  return new Paragraph({ spacing: { after: 200 }, children: [] });
}

// ---------- title page banner helper ----------
function fullWidthBanner(fill, rows) {
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [CONTENT_W],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: CONTENT_W, type: WidthType.DXA },
            shading: { type: ShadingType.CLEAR, fill },
            verticalAlign: VerticalAlign.CENTER,
            margins: { top: 500, bottom: 500, left: 500, right: 500 },
            children: rows,
          }),
        ],
      }),
    ],
  });
}

// ---------- content ----------
const children = [];

// ===== Title Page =====
children.push(new Paragraph({ spacing: { after: 0 }, children: [] }));
children.push(fullWidthBanner(COLORS.teal, [
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 220 },
    children: [new TextRun({ text: "LOGISTICS ANALYTICS", bold: true, color: COLORS.gold, font: FONT_HEAD, size: 22, characterSpacing: 20 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 260 },
    children: [new TextRun({ text: "Advanced Data Analysis and Visualization in Logistics", bold: true, size: 48, color: "FFFFFF", font: FONT_HEAD })] }),
  new Paragraph({ alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "Week 3 Analytical Report", size: 26, color: COLORS.gold, font: FONT_HEAD, italics: true })] }),
]));
children.push(new Paragraph({ spacing: { before: 700, after: 500 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Exploratory Analysis, Visualization, and Operational Insights from a Simulated Logistics Dataset", size: 23, italics: true, font: FONT_BODY, color: COLORS.gray })] }));
children.push(fullWidthBanner(COLORS.cream, [
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 90 },
    children: [new TextRun({ text: "PREPARED WITH", bold: true, color: COLORS.coral, font: FONT_HEAD, size: 18, characterSpacing: 16 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "Python · pandas · NumPy · matplotlib · seaborn", size: 22, font: FONT_BODY, color: COLORS.navy, bold: true })] }),
]));
children.push(new Paragraph({ children: [new PageBreak()] }));

children.push(heading1("1.", "Executive Summary"));
children.push(body(
  "This report analyzes a simulated logistics dataset of 1,500 shipments across five regions, four carriers, and four transport modes (Road, Rail, Air, Sea) over a full calendar year. The objective is to demonstrate an end-to-end analytical workflow — data simulation, exploratory data analysis (EDA), visualization, and interpretation — applied to core logistics performance metrics: delivery time, cost, volume, and reliability."
));
children.push(body(
  "The analysis finds that overall on-time delivery performance sits at 52.9%, masking wide variation by mode (Air: 81.8% on-time vs. Road: 42.9%) and a severe seasonal bottleneck in November–December, when on-time performance collapses to roughly 22%. Cost analysis shows Air freight costs nearly 6x more per kilometer than Sea freight, while Road — the most heavily used mode — is also the least reliable. These findings translate into concrete recommendations on mode allocation, peak-season capacity planning, and carrier performance management, detailed in Section 6."
));

children.push(heading1("2.", "Objective and Methodology"));
children.push(body(
  "The task was to explore, analyze, and visualize logistics data using Python, drawing insights that support data-driven decision-making. The methodology followed five stages:"
));
children.push(bullet("Data Simulation: construct a realistic logistics dataset with interdependent variables (distance, mode, and season driving cost and delivery time)."));
children.push(bullet("Exploratory Data Analysis: compute descriptive statistics, distributions, and correlations using pandas."));
children.push(bullet("Visualization: build seven charts using matplotlib and seaborn, each chosen to answer a specific operational question."));
children.push(bullet("Insight extraction: interpret each visualization in terms of operational efficiency, cost drivers, and bottlenecks."));
children.push(bullet("Documentation: consolidate methodology, code, and findings into this report."));
children.push(body("All code was written in Python 3 and executed in a reproducible script-based pipeline (01_simulate_data.py → 02_eda.py → 03_visualize.py)."));

// Section 3: Data simulation
children.push(heading1("3.", "Data Simulation"));
children.push(body(
  "Because a live company dataset was not available, a hypothetical but statistically realistic dataset of 1,500 shipments was generated for calendar year 2025. Costs and delivery times were derived from each shipment's distance, transport mode, and volume, with added random noise and a deliberate peak-season congestion effect (November–December) to mimic real operational behavior."
));
children.push(heading2("3.1 Dataset Structure"));
children.push(dataTable(
  ["Variable", "Type", "Description"],
  [
    ["shipment_id", "String", "Unique shipment identifier"],
    ["ship_date", "Date", "Date shipment departed origin (Jan–Dec 2025)"],
    ["region", "Categorical", "Destination region: North, South, East, West, Central"],
    ["carrier", "Categorical", "Carrier company: A, B, C, D"],
    ["mode", "Categorical", "Transport mode: Road, Rail, Air, Sea"],
    ["distance_km", "Numeric", "Shipment distance in kilometers"],
    ["shipment_volume_kg", "Numeric", "Shipment weight in kilograms"],
    ["transportation_cost_usd", "Numeric", "Total cost to move the shipment"],
    ["fuel_surcharge_pct", "Numeric", "Fuel surcharge applied to base cost"],
    ["planned_delivery_days", "Integer", "Contracted transit time"],
    ["actual_delivery_days", "Integer", "Observed transit time"],
    ["delay_days / delayed", "Integer / Boolean", "actual − planned; delay flag"],
  ],
  [2600, 1800, 6300]
));
children.push(sectionBreakSpace());
children.push(heading2("3.2 Simulation Code (excerpt)"));
children.push(body("The excerpt below shows how mode-specific cost and speed parameters were used to generate correlated, realistic values:"));
children.push(codeBlock([
  'mode_params = {',
  '    "Road": {"cost_per_km": 0.85, "speed_kmpd": 550, "time_noise": 0.7},',
  '    "Rail": {"cost_per_km": 0.45, "speed_kmpd": 400, "time_noise": 1.0},',
  '    "Air":  {"cost_per_km": 3.20, "speed_kmpd": 3000, "time_noise": 0.4},',
  '    "Sea":  {"cost_per_km": 0.20, "speed_kmpd": 300, "time_noise": 1.8},',
  '}',
  '',
  'base_cost = distance_km * params["cost_per_km"]',
  'volume_cost = shipment_volume_kg * 0.35',
  'transportation_cost_usd = (base_cost + volume_cost) * cost_noise',
  '',
  'planned_delivery_days = distance_km / params["speed_kmpd"] + 1',
  'peak_penalty = 0.8 if ship_date.month in (11, 12) else 0        # holiday-season congestion',
  'congestion_penalty = 0.5 if mode == "Road" else 0               # road traffic variability',
  'actual_delivery_days = planned_delivery_days + time_noise + peak_penalty + congestion_penalty',
]));

// Section 4: EDA
children.push(heading1("4.", "Exploratory Data Analysis"));
children.push(heading2("4.1 Central Tendency and Spread"));
children.push(body("Descriptive statistics for the core numeric variables (rounded to two decimals):"));
children.push(dataTable(
  ["Variable", "Mean", "Median", "Std Dev", "Skew"],
  [
    ["Distance (km)", "758.6", "731.7", "337.7", "1.10"],
    ["Volume (kg)", "1,058.8", "952.6", "617.4", "1.16"],
    ["Cost (USD)", "1,118.6", "866.9", "865.8", "2.62"],
    ["Fuel Surcharge (%)", "8.0", "8.0", "2.5", "0.06"],
    ["Planned Days", "2.5", "2.0", "1.1", "0.82"],
    ["Actual Days", "3.0", "3.0", "1.5", "0.79"],
    ["Delay (days)", "0.5", "0.0", "1.1", "0.03"],
  ],
  [3000, 1700, 1700, 1700, 1600]
));
children.push(body(
  "Cost is the most heavily right-skewed variable (skew = 2.62), meaning a small share of high-cost shipments (mostly long-haul Air freight) pulls the mean well above the median — a pattern confirmed visually in Section 5.3. Delivery time variables show mild positive skew, consistent with delays being more common than early arrivals of equal magnitude."
));

children.push(heading2("4.2 On-Time Performance Breakdown"));
children.push(dataTable(
  ["Segment", "On-Time Rate"],
  [
    ["Overall", "52.9%"],
    ["Air", "81.8%"],
    ["Rail", "63.1%"],
    ["Sea", "51.5%"],
    ["Road", "42.9%"],
    ["Best region — North", "55.1%"],
    ["Worst region — West", "51.9%"],
    ["Best carrier — Carrier C", "56.8%"],
    ["Worst carrier — Carrier B", "49.4%"],
  ],
  [4500, 4500]
));

children.push(heading2("4.3 Correlation Analysis"));
children.push(body(
  "A Pearson correlation matrix (Section 5.4) was computed across the numeric variables. The strongest relationships are: distance vs. planned delivery days (r = 0.65), actual vs. planned delivery days (r = 0.72), and actual delivery days vs. delay days (r = 0.67). Notably, transportation cost is negatively correlated with planned delivery days (r = -0.34) — a counterintuitive result explained by transport mode: Air shipments are fast (low planned days) but expensive, while Sea shipments are slow but cheap. This illustrates why looking at cost or time in isolation, without segmenting by mode, can mislead decision-making."
));

// Section 5: Visualizations
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(heading1("5.", "Visualizations"));
children.push(body("Seven visualizations were produced, each selected because it best answers a specific operational question. For each chart below: the question it answers, the Python code used, the chart itself, and the interpretation."));

const charts = [
  {
    title: "5.1 Distribution of Planned vs. Actual Delivery Time",
    question: "How is delivery performance distributed, and how far does reality diverge from plan?",
    code: [
      'sns.histplot(df["planned_delivery_days"], kde=True, stat="density",',
      '             color="#4C72B0", label="Planned", alpha=0.45)',
      'sns.histplot(df["actual_delivery_days"], kde=True, stat="density",',
      '             color="#DD8452", label="Actual", alpha=0.45)',
    ],
    file: "../charts/hist_delivery_time.png",
    why: "An overlaid histogram with density curves is the clearest way to compare two distributions of the same unit (days) directly, showing both the shift in central tendency and the change in spread.",
    insight: "The actual delivery distribution is shifted right and more spread out than the planned distribution, confirming that delays are systemic rather than isolated incidents — the whole distribution moves, not just the tail.",
  },
  {
    title: "5.2 Delivery Delay by Transport Mode",
    question: "Which transport mode is least reliable, and by how much?",
    code: [
      'order = df.groupby("mode")["delay_days"].median().sort_values().index',
      'sns.boxplot(data=df, x="mode", y="delay_days", order=order)',
      'ax.axhline(0, color="gray", linestyle="--")   # 0 = on-plan',
    ],
    file: "../charts/box_delay_by_mode.png",
    why: "Boxplots reveal median, interquartile spread, and outliers simultaneously — essential for comparing reliability (not just average delay) across categories.",
    insight: "Road shows the widest interquartile range and the highest median delay, while Air is tightly clustered around zero. This indicates Road's problem is variability and unpredictability, not just average speed — a harder operational issue to fix than raw transit time.",
  },
  {
    title: "5.3 Transportation Cost vs. Distance by Mode",
    question: "How does cost scale with distance, and does the relationship differ by mode?",
    code: [
      'sns.scatterplot(data=df, x="distance_km", y="transportation_cost_usd",',
      '                hue="mode", alpha=0.65, s=35)',
    ],
    file: "../charts/scatter_cost_distance.png",
    why: "A color-coded scatterplot exposes both the overall cost-distance relationship and hidden sub-groups (modes) with different slopes — patterns a single trend line would obscure.",
    insight: "Air (gold cluster) sits on a much steeper cost-per-km slope than Sea or Rail, confirming that mode, not distance alone, is the dominant cost driver for long-haul shipments.",
  },
  {
    title: "5.4 Correlation Matrix of Key Logistics Variables",
    question: "Which operational variables move together, and which relationships are counterintuitive?",
    code: [
      'corr = df[numeric_cols].corr()',
      'teal_gold_cmap = sns.diverging_palette(175, 40, s=75, l=45, as_cmap=True)',
      'sns.heatmap(corr, annot=True, fmt=".2f", cmap=teal_gold_cmap, center=0, square=True)',
    ],
    file: "../charts/corr_heatmap.png",
    why: "A heatmap condenses many pairwise relationships into one glanceable view, using color intensity to draw the eye straight to the strongest (positive or negative) correlations.",
    insight: "The negative correlation between cost and planned delivery days (-0.34) is the most actionable finding here: it warns analysts against assuming 'faster is always more expensive' without first controlling for transport mode.",
  },
  {
    title: "5.5 Monthly Shipment Volume vs. On-Time Delivery Rate",
    question: "How do shipment volume and service reliability trend across the year, and do they interact?",
    code: [
      'ax1.bar(monthly.index, monthly["total_volume_kg"] / 1000)      # tonnes',
      'ax2 = ax1.twinx()',
      'ax2.plot(monthly.index, monthly["on_time_rate"], color="#C44E52", marker="o")',
    ],
    file: "../charts/monthly_trend.png",
    why: "A dual-axis combination chart is appropriate here because volume (tonnes) and rate (%) are on different scales but need to be read together to see whether one drives the other.",
    insight: "On-time performance is fairly stable (55-63%) from January through October, then collapses to ~22% in November-December — precisely the peak shipping season. This is the single clearest bottleneck in the dataset and points to a capacity, not a quality, problem.",
  },
  {
    title: "5.6 On-Time Delivery Rate by Region",
    question: "Where are the biggest regional service gaps?",
    code: [
      'otp_region = df.groupby("region")["delayed"].apply(lambda x: (~x).mean()*100)',
      'ax.bar(otp_region.index, otp_region.values)',
      'ax.axhline(otp_region.mean(), linestyle="--")   # benchmark line',
    ],
    file: "../charts/bar_ontime_region.png",
    why: "A simple ranked bar chart with a benchmark line is the most direct way to compare a single metric across a small number of categories and flag under/over performers at a glance.",
    insight: "Regional on-time rates are fairly close together (51.9%-55.1%), which suggests the primary driver of unreliability is mode and season rather than geography — regional-level fixes would have limited impact compared to mode- or season-level ones.",
  },
  {
    title: "5.7 Average Cost per Kilometer by Transport Mode",
    question: "Which mode is most cost-efficient, independent of distance travelled?",
    code: [
      'cpk = (df["transportation_cost_usd"] / df["distance_km"]).groupby(df["mode"]).mean()',
      'ax.bar(cpk.index, cpk.values)',
    ],
    file: "../charts/cost_per_km_mode.png",
    why: "Normalizing cost by distance (cost per km) removes the confound of shipment length, isolating the true efficiency of each mode for an apples-to-apples comparison.",
    insight: "Air costs $3.70/km versus Sea's $0.64/km — nearly 6x. Combined with Section 5.2's reliability finding, this frames the core logistics trade-off: Air buys reliability at a steep premium, while Road offers a weak middle ground (moderate cost, poor reliability).",
  },
];

for (const c of charts) {
  children.push(heading2(c.title));
  children.push(body(`Question: ${c.question}`, { italics: true, color: COLORS.gray }));
  children.push(codeBlock(c.code));
  children.push(img(c.file, 500, 320));
  children.push(caption(c.title.replace(/^5\.\d+ /, "")));
  children.push(callout("WHY THIS CHART", c.why, COLORS.teal, COLORS.mint));
  children.push(new Paragraph({ spacing: { after: 160 }, children: [] }));
  children.push(callout("INSIGHT", c.insight, COLORS.gold, COLORS.cream));
  children.push(new Paragraph({ spacing: { after: 200 }, children: [] }));
}

// Section 6: Insights & recommendations
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(heading1("6.", "Analytical Insights and Recommendations"));

children.push(heading2("6.1 Key Findings"));
children.push(bullet("Systemic delay, not isolated incidents: the entire actual-delivery-time distribution is shifted right of plan, indicating a structural gap between contracted and real transit times."));
children.push(bullet("Road is the weak link: 55% of all shipments travel by Road, yet Road has the lowest on-time rate (42.9%) and widest delay variability of any mode."));
children.push(bullet("Peak season is the dominant bottleneck: on-time performance falls from a 55-63% baseline to ~22% in November-December, coinciding with the highest-volume months."));
children.push(bullet("Cost and speed trade off by mode, not by distance: Air is ~6x more expensive per km than Sea but is the most reliable mode (81.8% on-time); cost decisions should be made per-mode, not on blended averages."));
children.push(bullet("Regional differences are minor: on-time rates vary by only ~3 points across regions, so mode and seasonal fixes will have far more impact than regional interventions."));

children.push(heading2("6.2 Recommendations"));
children.push(bullet("Add peak-season surge capacity (extra carriers or shifted freight to Rail/Air) for November-December specifically, rather than applying uniform year-round capacity planning."));
children.push(bullet("Reduce Road's share of volume for time-sensitive or high-value shipments, shifting a portion to Rail, which delivers meaningfully better reliability (63.1% vs. 42.9%) at a lower cost premium than Air."));
children.push(bullet("Investigate Carrier B specifically (lowest on-time rate at 49.4%) for root causes — driver capacity, routing, or contract SLAs — before renewing or expanding volume with them."));
children.push(bullet("Use mode-segmented cost benchmarks (cost per km by mode) rather than a single blended cost KPI, since blended averages mask the true efficiency of each mode."));
children.push(bullet("Set differentiated on-time SLAs by mode and season, since a single company-wide on-time target obscures very different underlying performance levels."));

children.push(heading1("7.", "Conclusion"));
children.push(body(
  "This analysis demonstrates how a structured, code-driven EDA and visualization workflow can convert raw shipment-level data into concrete operational recommendations. The most consequential finding — a severe peak-season reliability collapse layered on top of a chronic Road-mode weakness — was only visible by combining time-series, distributional, and categorical visualizations together. In a live business setting, this same workflow (simulate/ingest → EDA → targeted visualization → segmented interpretation) could be re-run monthly against real shipment data to track whether the recommended interventions are closing the gaps identified here."
));

children.push(heading1("8.", "Appendix: Full Python Pipeline"));
children.push(body("The complete three-script pipeline (data simulation, EDA, visualization) used to produce this report is included as a separate file set: 01_simulate_data.py, 02_eda.py, and 03_visualize.py. Library versions used: pandas, NumPy, matplotlib, and seaborn (all current stable releases as of analysis date)."));

// ---------- document assembly ----------
const doc = new Document({
  numbering: {
    config: [
      {
        reference: "bullet-list",
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: convertInchesToTwip(0.35), hanging: convertInchesToTwip(0.2) } } } },
        ],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: PAGE_W, height: PAGE_H },
          margin: { top: convertInchesToTwip(1), bottom: convertInchesToTwip(1), left: convertInchesToTwip(1), right: convertInchesToTwip(1) },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.RIGHT,
            border: { bottom: { color: COLORS.gold, space: 4, style: BorderStyle.SINGLE, size: 6 } },
            children: [new TextRun({ text: "LOGISTICS DATA ANALYSIS  ·  WEEK 3 REPORT", size: 15, font: FONT_HEAD, color: COLORS.teal, bold: true, characterSpacing: 8 })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: "Page ", size: 16, font: FONT_BODY, color: COLORS.gray }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, font: FONT_BODY, color: COLORS.gold, bold: true }),
            ],
          })],
        }),
      },
      children,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("../report/Logistics_Data_Analysis_Report.docx", buf);
  console.log("Report written.");
});
