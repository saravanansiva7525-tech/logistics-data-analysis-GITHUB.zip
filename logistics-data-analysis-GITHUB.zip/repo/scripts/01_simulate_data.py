"""
Step 1: Data Simulation
------------------------
Creates a hypothetical logistics dataset representing 1,500 shipments
over a 12-month period for a mid-size distribution company operating
across five regions and four carriers, using four transport modes.

Key variables:
- shipment_id            : unique identifier
- ship_date               : date shipment left origin
- region                  : destination region (5 categories)
- carrier                 : carrier company (4 categories)
- mode                    : transport mode (Road, Rail, Air, Sea)
- distance_km             : shipment distance in kilometers
- shipment_volume_kg      : weight of shipment in kilograms
- transportation_cost_usd : total cost to move the shipment
- planned_delivery_days   : contracted/planned transit time
- actual_delivery_days    : observed transit time
- delay_days              : actual - planned (can be negative = early)
- delayed                 : boolean flag, actual > planned
- fuel_surcharge_pct      : fuel surcharge applied to base cost
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 1500

regions = ["North", "South", "East", "West", "Central"]
region_probs = [0.22, 0.18, 0.20, 0.22, 0.18]

carriers = ["Carrier A", "Carrier B", "Carrier C", "Carrier D"]
carrier_probs = [0.30, 0.28, 0.24, 0.18]

modes = ["Road", "Rail", "Air", "Sea"]
mode_probs = [0.55, 0.18, 0.12, 0.15]

# Base cost/time characteristics per mode (per-km cost, speed, variability)
mode_params = {
    "Road": {"cost_per_km": 0.85, "speed_kmpd": 550, "time_noise": 0.7, "cost_noise": 0.12},
    "Rail": {"cost_per_km": 0.45, "speed_kmpd": 400, "time_noise": 1.0, "cost_noise": 0.10},
    "Air":  {"cost_per_km": 3.20, "speed_kmpd": 3000, "time_noise": 0.4, "cost_noise": 0.15},
    "Sea":  {"cost_per_km": 0.20, "speed_kmpd": 300, "time_noise": 1.8, "cost_noise": 0.20},
}

dates = pd.date_range("2025-01-01", "2025-12-31", freq="D")

rows = []
for i in range(1, N + 1):
    ship_date = np.random.choice(dates)
    region = np.random.choice(regions, p=region_probs)
    carrier = np.random.choice(carriers, p=carrier_probs)
    mode = np.random.choice(modes, p=mode_probs)
    params = mode_params[mode]

    distance_km = max(50, np.random.gamma(shape=4, scale=180))
    if mode == "Air":
        distance_km = max(distance_km, 600)  # air used mainly for longer hauls
    if mode == "Sea":
        distance_km = max(distance_km, 800)

    shipment_volume_kg = max(20, np.random.gamma(shape=3, scale=350))

    base_cost = distance_km * params["cost_per_km"]
    volume_cost = shipment_volume_kg * 0.35
    cost_noise = np.random.normal(1, params["cost_noise"])
    transportation_cost_usd = round(max(50, (base_cost + volume_cost) * cost_noise), 2)

    fuel_surcharge_pct = round(np.clip(np.random.normal(8, 2.5), 2, 18), 1)

    planned_delivery_days = max(1, round(distance_km / params["speed_kmpd"] + 1))
    time_noise = np.random.normal(0, params["time_noise"])
    # Peak season (Nov-Dec) and Road mode see more congestion-driven delay
    peak_penalty = 0.8 if pd.Timestamp(ship_date).month in (11, 12) else 0
    congestion_penalty = 0.5 if mode == "Road" else 0
    actual_delivery_days = max(1, round(
        planned_delivery_days + time_noise + peak_penalty + congestion_penalty
    ))

    delay_days = actual_delivery_days - planned_delivery_days
    delayed = delay_days > 0

    rows.append({
        "shipment_id": f"SHP-{i:05d}",
        "ship_date": pd.Timestamp(ship_date),
        "region": region,
        "carrier": carrier,
        "mode": mode,
        "distance_km": round(distance_km, 1),
        "shipment_volume_kg": round(shipment_volume_kg, 1),
        "transportation_cost_usd": transportation_cost_usd,
        "fuel_surcharge_pct": fuel_surcharge_pct,
        "planned_delivery_days": planned_delivery_days,
        "actual_delivery_days": actual_delivery_days,
        "delay_days": delay_days,
        "delayed": delayed,
    })

df = pd.DataFrame(rows).sort_values("ship_date").reset_index(drop=True)
df.to_csv("../data/logistics_data.csv", index=False)

print(df.shape)
print(df.head())
print(df.dtypes)
