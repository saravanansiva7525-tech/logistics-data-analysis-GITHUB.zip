"""
Step 2: Exploratory Data Analysis (EDA)
-----------------------------------------
Computes central tendency, spread, distribution shape, and correlation
statistics for the logistics dataset, and saves them to text/CSV so
they can be quoted directly in the report.
"""

import pandas as pd

pd.set_option("display.width", 120)
pd.set_option("display.max_columns", 20)

df = pd.read_csv("../data/logistics_data.csv", parse_dates=["ship_date"])

numeric_cols = [
    "distance_km", "shipment_volume_kg", "transportation_cost_usd",
    "fuel_surcharge_pct", "planned_delivery_days", "actual_delivery_days",
    "delay_days",
]

report_lines = []

def log(text=""):
    print(text)
    report_lines.append(text)

log("=== Dataset Overview ===")
log(f"Rows: {len(df)}, Columns: {df.shape[1]}")
log(f"Date range: {df.ship_date.min().date()} to {df.ship_date.max().date()}")
log("")

log("=== Descriptive Statistics (numeric variables) ===")
desc = df[numeric_cols].describe().T
desc["skew"] = df[numeric_cols].skew()
log(desc.round(2).to_string())
log("")

log("=== On-Time Performance ===")
otp_overall = (~df["delayed"]).mean() * 100
log(f"Overall on-time rate: {otp_overall:.1f}%")
otp_by_mode = df.groupby("mode")["delayed"].apply(lambda x: (~x).mean() * 100).sort_values(ascending=False)
log("On-time rate by mode (%):")
log(otp_by_mode.round(1).to_string())
otp_by_region = df.groupby("region")["delayed"].apply(lambda x: (~x).mean() * 100).sort_values(ascending=False)
log("On-time rate by region (%):")
log(otp_by_region.round(1).to_string())
otp_by_carrier = df.groupby("carrier")["delayed"].apply(lambda x: (~x).mean() * 100).sort_values(ascending=False)
log("On-time rate by carrier (%):")
log(otp_by_carrier.round(1).to_string())
log("")

log("=== Cost Summary ===")
cost_by_mode = df.groupby("mode")["transportation_cost_usd"].agg(["mean", "median", "sum"]).sort_values("mean", ascending=False)
log("Cost by mode (USD):")
log(cost_by_mode.round(2).to_string())
log("")
avg_cost_per_km = (df["transportation_cost_usd"] / df["distance_km"]).groupby(df["mode"]).mean().sort_values(ascending=False)
log("Average cost per km by mode (USD/km):")
log(avg_cost_per_km.round(2).to_string())
log("")

log("=== Correlation Matrix ===")
corr = df[numeric_cols].corr()
log(corr.round(2).to_string())
log("")

log("=== Monthly Trend Summary ===")
monthly = df.set_index("ship_date").resample("ME").agg(
    shipments=("shipment_id", "count"),
    avg_cost=("transportation_cost_usd", "mean"),
    total_volume_kg=("shipment_volume_kg", "sum"),
    on_time_rate=("delayed", lambda x: (~x).mean() * 100),
)
log(monthly.round(1).to_string())

with open("../docs/eda_summary.txt", "w") as f:
    f.write("\n".join(report_lines))

corr.to_csv("../docs/correlation_matrix.csv")
monthly.to_csv("../docs/monthly_summary.csv")
desc.to_csv("../docs/descriptive_stats.csv")
