"""
Step 3: Visualizations
------------------------
Generates the chart set used in the report. Each chart is chosen to
answer a specific logistics question:

1. hist_delivery_time.png     -> How is delivery performance distributed?
2. box_delay_by_mode.png      -> Which transport mode is least reliable?
3. scatter_cost_distance.png  -> How do cost and distance relate, and does mode change that?
4. corr_heatmap.png           -> Which operational variables move together?
5. monthly_trend.png          -> How do volume, cost, and on-time rate trend over the year?
6. bar_ontime_region.png      -> Where are the biggest service bottlenecks by region?
7. cost_per_km_mode.png       -> Which mode is the most/least cost-efficient per km?
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid", context="talk", font_scale=0.75)

# ---- Brand palette: deep teal / amber gold / coral / ink navy ----
TEAL = "#0B5D57"
GOLD = "#D4A017"
CORAL = "#E2725B"
NAVY = "#1B3A4B"
SLATE = "#5C7A7A"
MODE_COLORS = {"Road": CORAL, "Rail": TEAL, "Air": GOLD, "Sea": NAVY}
PALETTE = "crest"
OUT = "../charts"

plt.rcParams["axes.titleweight"] = "bold"
plt.rcParams["axes.titlecolor"] = TEAL
plt.rcParams["font.family"] = "DejaVu Sans"

df = pd.read_csv("../data/logistics_data.csv", parse_dates=["ship_date"])

# ---------------------------------------------------------------
# 1. Distribution of delivery times (planned vs actual)
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 5))
sns.histplot(df["planned_delivery_days"], color=TEAL, label="Planned", kde=True,
             stat="density", alpha=0.55, ax=ax, bins=9)
sns.histplot(df["actual_delivery_days"], color=CORAL, label="Actual", kde=True,
             stat="density", alpha=0.55, ax=ax, bins=9)
ax.set_title("Distribution of Planned vs. Actual Delivery Time")
ax.set_xlabel("Delivery Time (days)")
ax.set_ylabel("Density")
ax.legend()
fig.tight_layout()
fig.savefig(f"{OUT}/hist_delivery_time.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------
# 2. Delay days by transport mode (boxplot)
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 5))
order = df.groupby("mode")["delay_days"].median().sort_values().index
sns.boxplot(data=df, x="mode", y="delay_days", order=order, hue="mode",
            palette=MODE_COLORS, legend=False, ax=ax)
ax.axhline(0, color=NAVY, linestyle="--", linewidth=1.2, alpha=0.7)
ax.set_title("Delivery Delay by Transport Mode")
ax.set_xlabel("Transport Mode")
ax.set_ylabel("Delay (days, actual - planned)")
fig.tight_layout()
fig.savefig(f"{OUT}/box_delay_by_mode.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------
# 3. Cost vs distance scatter, colored by mode
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(8, 5.5))
sns.scatterplot(data=df, x="distance_km", y="transportation_cost_usd", hue="mode",
                 palette=MODE_COLORS, alpha=0.7, s=38, ax=ax, edgecolor="white", linewidth=0.3)
ax.set_title("Transportation Cost vs. Distance by Mode")
ax.set_xlabel("Distance (km)")
ax.set_ylabel("Transportation Cost (USD)")
ax.yaxis.set_major_formatter(mticker.StrMethodFormatter("${x:,.0f}"))
ax.legend(title="Mode", loc="upper left")
fig.tight_layout()
fig.savefig(f"{OUT}/scatter_cost_distance.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------
# 4. Correlation heatmap
# ---------------------------------------------------------------
numeric_cols = [
    "distance_km", "shipment_volume_kg", "transportation_cost_usd",
    "fuel_surcharge_pct", "planned_delivery_days", "actual_delivery_days",
    "delay_days",
]
corr = df[numeric_cols].corr()
labels = ["Distance", "Volume", "Cost", "Fuel Surch.", "Planned Days", "Actual Days", "Delay Days"]
teal_gold_cmap = sns.diverging_palette(175, 40, s=75, l=45, as_cmap=True)
fig, ax = plt.subplots(figsize=(8, 6.5))
sns.heatmap(corr, annot=True, fmt=".2f", cmap=teal_gold_cmap, center=0, square=True,
            xticklabels=labels, yticklabels=labels, cbar_kws={"shrink": 0.8},
            linewidths=0.6, linecolor="white", ax=ax)
ax.set_title("Correlation Matrix of Key Logistics Variables")
plt.xticks(rotation=40, ha="right")
fig.tight_layout()
fig.savefig(f"{OUT}/corr_heatmap.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------
# 5. Monthly trend: shipment volume (bars) vs on-time rate (line)
# ---------------------------------------------------------------
monthly = df.set_index("ship_date").resample("ME").agg(
    total_volume_kg=("shipment_volume_kg", "sum"),
    on_time_rate=("delayed", lambda x: (~x).mean() * 100),
    avg_cost=("transportation_cost_usd", "mean"),
)
monthly.index = monthly.index.strftime("%b")

fig, ax1 = plt.subplots(figsize=(9.5, 5.5))
ax1.bar(monthly.index, monthly["total_volume_kg"] / 1000, color=SLATE, alpha=0.85, label="Shipment Volume (t)")
ax1.set_ylabel("Total Shipment Volume (tonnes)")
ax1.set_xlabel("Month (2025)")
ax1.tick_params(axis="x", rotation=0)

ax2 = ax1.twinx()
ax2.plot(monthly.index, monthly["on_time_rate"], color=CORAL, marker="o", linewidth=2.8, label="On-Time Rate (%)")
ax2.set_ylabel("On-Time Delivery Rate (%)")
ax2.set_ylim(0, 100)
ax2.grid(False)

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="lower left")
ax1.set_title("Monthly Shipment Volume vs. On-Time Delivery Rate")
fig.tight_layout()
fig.savefig(f"{OUT}/monthly_trend.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------
# 6. On-time rate by region (bar)
# ---------------------------------------------------------------
otp_region = df.groupby("region")["delayed"].apply(lambda x: (~x).mean() * 100).sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 5))
teal_shades = sns.light_palette(TEAL, n_colors=len(otp_region) + 2, reverse=True)[0:len(otp_region)]
bars = ax.bar(otp_region.index, otp_region.values, color=teal_shades)
ax.axhline(otp_region.mean(), color=GOLD, linestyle="--", linewidth=1.6, label=f"Average ({otp_region.mean():.1f}%)")
for b in bars:
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 1, f"{b.get_height():.1f}%", ha="center", fontsize=10)
ax.set_ylim(0, 75)
ax.set_title("On-Time Delivery Rate by Region")
ax.set_xlabel("Region")
ax.set_ylabel("On-Time Rate (%)")
ax.legend()
fig.tight_layout()
fig.savefig(f"{OUT}/bar_ontime_region.png", dpi=150)
plt.close(fig)

# ---------------------------------------------------------------
# 7. Cost efficiency per km by mode
# ---------------------------------------------------------------
cpk = (df["transportation_cost_usd"] / df["distance_km"]).groupby(df["mode"]).mean().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(cpk.index, cpk.values, color=[MODE_COLORS[m] for m in cpk.index])
for b in bars:
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.05, f"${b.get_height():.2f}", ha="center", fontsize=10)
ax.set_title("Average Cost per Kilometer by Transport Mode")
ax.set_xlabel("Transport Mode")
ax.set_ylabel("Cost per km (USD)")
fig.tight_layout()
fig.savefig(f"{OUT}/cost_per_km_mode.png", dpi=150)
plt.close(fig)

print("All charts saved to", OUT)
